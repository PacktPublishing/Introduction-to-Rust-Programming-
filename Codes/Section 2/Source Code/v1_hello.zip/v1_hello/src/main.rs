fn main() {
    println!("Hello, all of you!");
    for x in 0..5 {
        println!("{}", x);
    }
}
